package test;

import java.net.URI;
import java.net.URISyntaxException;

public class TestURI {
    public static void main(String[] args) throws URISyntaxException {
        URI uri=new URI("httpwww.baidu.com");
        System.out.println(uri.getHost());

        System.out.println(uri.getPath());
    }
}
