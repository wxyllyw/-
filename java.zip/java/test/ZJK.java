package test;

import java.util.concurrent.locks.ReentrantLock;

public class ZJK {
    public static void main(String[] args) {
        ReentrantLock lock=new ReentrantLock();

        lock.lock();

        lock.unlock();
    }
}
