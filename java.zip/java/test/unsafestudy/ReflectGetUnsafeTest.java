package test.unsafestudy;

import sun.misc.Unsafe;

import java.lang.reflect.Field;



public class ReflectGetUnsafeTest {
    //通过反射获取单例对象theUnsafe。
    // 在Unsafe类中有一个属性，表示的是Unsafe类的单例对象
    static Unsafe reflectGetUnsafe(){
        try{
            Field field=Unsafe.class.getDeclaredField("theUnsafe");
            field.setAccessible(true);
            return (Unsafe)field.get(null);
        }catch (Exception e){
            System.out.println(e.getMessage());
            return null;
        }
    }

    public static void main(String[] args) {
        Object o=reflectGetUnsafe();
        System.out.println(o);
    }
}
