package test.reentrant_lock_test;

import java.util.concurrent.locks.ReentrantLock;

// ReentrantLock解决死锁问题
public class ReentrantLockTest2 {
    static ReentrantLock reentrantLock=new ReentrantLock();

    static boolean getA(){
        reentrantLock.lock();
        try {
            System.out.println(Thread.currentThread().getName()+"获得资源A");
            Thread.sleep(3000);
            return true;
        }catch (Exception e){
            return false;
        }finally {
            reentrantLock.unlock();
        }
    }

    static boolean getB(){
        reentrantLock.lock();
        try {
            System.out.println(Thread.currentThread().getName()+"获得资源B");
            Thread.sleep(3000);
            return true;
        }catch (Exception e){
            return false;
        }finally {
            reentrantLock.unlock();
        }
    }
    static void getAB(){
        boolean isAGet=getA();
        boolean isBGet=getB();
    }


    public static void main(String[] args) {
        new Thread(new Runnable() {
            public void run() {
                boolean isAGet=getA();
                boolean isBGet=getB();
                if(isAGet&isBGet){
                    System.out.println(Thread.currentThread().getName()+"获得所有资源");
                }
            }
        },"t1").start();
        new Thread(new Runnable() {
            public void run() {
                boolean isBGet=getB();
                boolean isAGet=getA();
                if(isAGet&isBGet){
                    System.out.println(Thread.currentThread().getName()+"获得所有资源");
                }
            }
        },"t2").start();
    }
}
