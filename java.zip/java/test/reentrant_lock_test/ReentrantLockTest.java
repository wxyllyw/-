package test.reentrant_lock_test;


import java.util.concurrent.locks.ReentrantLock;

// ReentrantLock是可重入的锁
// 通过这个程序，可以看出ReentrantLock支持可重入
public class ReentrantLockTest {
    static Integer count=0;
    static ReentrantLock reentrantLock=new ReentrantLock();
    static void printCurrentThreadName(){
        reentrantLock.lock();
        System.out.println(Thread.currentThread().getName()+"获取到了锁");
        count=count+1;
        if (count%5!=0)
            printCurrentThreadName();
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        reentrantLock.unlock();
        System.out.println(Thread.currentThread().getName()+"释放了锁");
    }

    public static void main(String[] args) {
        Runnable runnable=new Runnable() {
            public void run() {
                printCurrentThreadName();
            }
        };
        Thread t1=new Thread(runnable,"t1");
        Thread t2=new Thread(runnable,"t2");
        t1.start();
        t2.start();
    }
}
