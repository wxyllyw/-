package test.ReentrantReadWriteLockTest;

import java.util.concurrent.locks.ReentrantReadWriteLock;
// 对于锁降级来说的
// 比如有2个线程写名字，5个线程读名字 那么对于两次写来说，
// 写‘张三’，接着写‘’李四，
// 但是对于读线程来说，那么所有的5个线程都要在写李四之前读取到‘张三’，这样才可以接着写李四
// 另外对于两个写线程来说，不可以同时写‘李四’，所以要用cacheValid来进行判断
/**
* * class CachedData {
 *   Object data;
 *   volatile boolean cacheValid;
 *   final ReentrantReadWriteLock rwl = new ReentrantReadWriteLock();
 *
 *   void processCachedData() {
 *     rwl.readLock().lock();
 *     if (!cacheValid) {
 *       // Must release read lock before acquiring write lock
 *       rwl.readLock().unlock();
 *       rwl.writeLock().lock();
 *       try {
 *         // Recheck state because another thread might have
 *         // acquired write lock and changed state before we did.
 *         if (!cacheValid) {
 *           data = ...
 *           cacheValid = true;
 *         }
 *         // Downgrade by acquiring read lock before releasing write lock
 *         rwl.readLock().lock();
 *       } finally {
 *         rwl.writeLock().unlock(); // Unlock write, still hold read
 *       }
 *     }
 *
 *     try {
 *       use(data);
 *     } finally {
 *       rwl.readLock().unlock();
 *     }
 *   }
 * }}</pre>
 */

// 下面的这个程序
// 我们来实现简单的缓存
//class CachedData{
//    String name;
//    volatile boolean cachedValid;
//    final ReentrantReadWriteLock rwl=new ReentrantReadWriteLock();
//
//    void processCachedData(String name){
//        rwl.readLock().lock();
//        rwl.writeLock().lock();
//        if(!cachedValid)
//
//    }
//}
//public class ReentrantReadWriteLockTest2 {
//
//}
