package test.hashmap;

import java.util.HashMap;

public class HashMapTest {
    public static void main(String[] args) {
        HashMap<String,Double> hashMap=new HashMap<String, Double>();

    }
}
