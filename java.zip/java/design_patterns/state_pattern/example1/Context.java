package design_patterns.state_pattern.example1;

public class Context {
    LiftState liftState;

    static LiftState openingState=new OpeningState();
    static LiftState closingState=new ClosingState();
    static LiftState runningState=new RunningState();
    static LiftState stoppingState=new StoppingState();

    public void setLiftState(LiftState liftState) {
        this.liftState = liftState;
        this.liftState.setContext(this);
    }

    public LiftState getLiftState() {
        return liftState;
    }

    void open(){
        liftState.open();
    }
    void close(){
        liftState.close();
    }

    void run(){
        liftState.run();
    }

    void stop(){
        liftState.stop();
    }


}
