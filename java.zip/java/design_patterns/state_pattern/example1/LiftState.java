package design_patterns.state_pattern.example1;

public abstract class LiftState {
    Context context;

    public void setContext(Context context) {
        this.context = context;
    }
    abstract void open();
    abstract void close();
    abstract void run();
    abstract void stop();
}
