package design_patterns.state_pattern.example1;

public class RunningState extends LiftState{
    @Override
    void open() {
        System.out.println("运行状态中，不可以开门呀");
    }

    @Override
    void close() {
        System.out.println("运行状态，门已经关了");
    }

    @Override
    void run() {
        System.out.println("已经是运行状态了");
    }

    @Override
    void stop() {
        super.context.setLiftState(Context.stoppingState);
        System.out.println("电梯成功进入停止状态");
    }
}
