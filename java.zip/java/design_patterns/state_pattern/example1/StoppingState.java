package design_patterns.state_pattern.example1;

public class StoppingState extends LiftState {
    @Override
    void open() {

    }

    @Override
    void close() {

    }

    @Override
    void run() {

    }

    @Override
    void stop() {

    }
}
