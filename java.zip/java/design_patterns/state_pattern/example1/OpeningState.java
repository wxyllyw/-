package design_patterns.state_pattern.example1;

public class OpeningState extends LiftState{

    @Override
    void open() {
        System.out.println("已经是开门状态");
    }

    @Override
    void close() {
        super.context.setLiftState(Context.closingState);
        System.out.println("成功从开门状态进入关门状态");
    }

    @Override
    void run() {
        System.out.println("开门状态，无法进入运行状态");
    }

    @Override
    void stop() {
        System.out.println("开着状态，无法进入停止状态");
    }
}
