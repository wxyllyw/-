package design_patterns.state_pattern.example1;

public class ClosingState extends LiftState {
    @Override
    void open() {
        super.context.setLiftState(Context.openingState);
        System.out.println("成功从停止状态进入开门状态");
    }

    @Override
    void close() {
        System.out.println("已经在关门状态了");
    }

    @Override
    void run() {
        super.context.setLiftState(Context.runningState);
        System.out.println("成功从停止状态进入运行状态");
    }

    @Override
    void stop() {
        System.out.println("停止状态，不可以进行关门得我操作");
    }
}
