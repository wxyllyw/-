package design_patterns.visitor_pattern.example1;

public class YoungActor extends ABSActor {
    public void act(KungFuRole role){
        System.out.println("年轻的演员可以演好功夫片");
    }

    public void act(IdiotRole role){
        System.out.println("弱智的角色，年轻演员可以演好");
    }
}
