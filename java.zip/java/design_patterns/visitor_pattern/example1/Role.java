package design_patterns.visitor_pattern.example1;

public interface Role {
    public void accept(ABSActor actor);
}
