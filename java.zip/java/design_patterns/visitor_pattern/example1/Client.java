package design_patterns.visitor_pattern.example1;

public class Client {
    public static void main(String[] args) {
        ABSActor actor=new OldActor();
        Role role=new KungFuRole();
        role.accept(actor);


        Role role1=new IdiotRole();
        role1.accept(actor);
    }
}
