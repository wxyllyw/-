package design_patterns.visitor_pattern.example1;

public class KungFuRole implements Role{
    @Override
    public void accept(ABSActor actor) {
        actor.act(this);
    }
}

