package design_patterns.visitor_pattern.example1;

public class OldActor extends ABSActor {
    public void act(KungFuRole role) {
        System.out.println("年纪大了的演员，很难能拍功夫片");
    }

    public void act(IdiotRole role){
        System.out.println("弱智的角色，年纪大的可以演好");
    }
}
