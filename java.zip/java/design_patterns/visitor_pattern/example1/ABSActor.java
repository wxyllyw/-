package design_patterns.visitor_pattern.example1;

public abstract class ABSActor {

    public void act(IdiotRole role){

    }
    public void act(KungFuRole role){

    }
}
