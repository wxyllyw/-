package design_patterns.visitor_pattern.example1;

public class IdiotRole implements Role {
    @Override
    public void accept(ABSActor actor) {
        actor.act(this);
    }
}
