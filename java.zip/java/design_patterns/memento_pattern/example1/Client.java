package design_patterns.memento_pattern.example1;

public class Client {
    public static void main(String[] args) {
        Boy boy=new Boy("心情很好");
        System.out.println(boy.getState());
        Memento memento=boy.createMemento();
        boy.changeState();
        System.out.println(boy.getState());
        boy.restoreMemento(memento);
        System.out.println(boy.getState());
    }
}
