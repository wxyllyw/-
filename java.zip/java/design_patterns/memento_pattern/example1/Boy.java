package design_patterns.memento_pattern.example1;

public class Boy {
    String state;
    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public Boy(String state) {
        this.state = state;
    }

    void changeState(){
        this.state="心情可能很不好";
    }

    Memento createMemento(){
        return new Memento(state);
    }

    void restoreMemento(Memento _memento){
        state=_memento.getState();
    }



    @Override
    public String toString() {
        return "Boy{" +
                "state='" + state + '\'' +
                '}';
    }
}
