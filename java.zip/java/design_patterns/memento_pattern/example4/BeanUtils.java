package design_patterns.memento_pattern.example4;

import java.lang.Object;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;

public class BeanUtils {
    static HashMap<String,Object> backupProp(Object bean){
        HashMap<String, Object> result=new HashMap<>();
        try {
            BeanInfo beanInfo= Introspector.getBeanInfo(bean.getClass());
            PropertyDescriptor[] descriptors=beanInfo.getPropertyDescriptors();
            for(PropertyDescriptor descriptor:descriptors){
                String filedName=descriptor.getName();
                Method getter=descriptor.getReadMethod();
                Object filedValue=getter.invoke(bean,new Originator[]{});

                if(!filedName.equalsIgnoreCase("class")){
                    result.put(filedName,filedValue);
                }
            }
        } catch (IntrospectionException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }finally {
            return result;
        }
    }
    static void restoreProp(Object bean,HashMap<String,Object> proMap){
        try {
            BeanInfo beanInfo=Introspector.getBeanInfo(bean.getClass());
            PropertyDescriptor[] descriptors=beanInfo.getPropertyDescriptors();
            for (PropertyDescriptor descriptor:descriptors){
                String filedName=descriptor.getName();
                if (proMap.containsKey(filedName)){
                Method setter=descriptor.getWriteMethod();
                setter.invoke(bean,new Object[]{proMap.get(filedName)});
                }
            }
        } catch (IntrospectionException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
    }
}
