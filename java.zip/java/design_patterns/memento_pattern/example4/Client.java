package design_patterns.memento_pattern.example4;



public class Client {
    public static void main(String[] args) {
        Originator originator=new Originator();
        Caretaker caretaker=new Caretaker();
        originator.setName("张三");
        originator.setSex("男");
        originator.setPassword("12345");
        System.out.println(originator);
        caretaker.setMemento(originator.createMemento());

        originator.setName("李四");
        originator.setSex("女");
        originator.setPassword("123456");
        System.out.println(originator);
        originator.restoreMemento(caretaker.getMemento());
        System.out.println(originator);

    }


}
