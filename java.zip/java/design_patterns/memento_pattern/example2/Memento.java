package design_patterns.memento_pattern.example2;

public class Memento {
    String state;

    public void setState(String state) {
        this.state = state;
    }

    public Memento(String state) {
        this.state = state;
    }

    public String getState() {
        return state;
    }
}
