package design_patterns.memento_pattern.example5;

import java.util.HashMap;

public class Caretaker {
    HashMap<String,Memento> memMap=new HashMap<>();

    public Memento getMemento(String idx){
        return memMap.get(idx);
    }

    public void setMemento(String idx,Memento memento){
        memMap.put(idx,memento);
    }
}
