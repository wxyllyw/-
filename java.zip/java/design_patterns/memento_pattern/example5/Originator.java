package design_patterns.memento_pattern.example5;

public class Originator {
    String sex;
    String name;
    String password;



    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    Memento createMemento(){
        return new Memento(BeanUtils.backupProp(this));
    }
    void changeState(String name , String sex, String password){
        this.name=name;
        this.sex=sex;
        this.password=password;
    }

    void restoreMemento(Memento memento){
        BeanUtils.restoreProp(this,memento.getStateMap());
    }

    @Override
    public String toString() {
        return "name="+this.name+"\nsex="+this.sex+"\n"+this.password;
    }
}
