package design_patterns.memento_pattern.example3;

import design_patterns.memento_pattern.example3.Boy;

public class Client {
    public static void main(String[] args) {
        Boy boy=new Boy("心情很好");
        System.out.println(boy.getState());
        boy.changeState();
        System.out.println(boy.getState());
        boy.restoreMemento();
        System.out.println(boy.getState());
    }
}
