package design_patterns.memento_pattern.example3;

import design_patterns.memento_pattern.example2.Memento;

public class Boy implements Cloneable {
    String state;
    Boy originalBoy;
    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public Boy(String state) {
        this.state = state;
    }

    void changeState(){
        originalBoy=clone();
        this.state="心情可能很不好";
    }


    void restoreMemento(){
        this.state=originalBoy.state;
    }
    @Override
    public String toString() {
        return "Boy{" +
                "state='" + state + '\'' +
                '}';
    }

    @Override
    protected Boy clone() {
        Boy boy=null;
        try {
            boy= (Boy) super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }finally {
            return boy;
        }
    }
}
