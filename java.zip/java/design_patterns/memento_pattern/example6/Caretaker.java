package design_patterns.memento_pattern.example6;

import java.util.HashMap;

public class Caretaker {
    HashMap<String, IMemento> memMap=new HashMap<>();

    public IMemento getMemento(String idx){
        return memMap.get(idx);
    }

    public void setMemento(String idx, IMemento memento){
        memMap.put(idx,memento);
    }
}
