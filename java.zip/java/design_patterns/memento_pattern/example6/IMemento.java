package design_patterns.memento_pattern.example6;

public interface IMemento {
}
