package design_patterns.memento_pattern.example6;


public class Client {
    public static void main(String[] args) {
        Originator originator=new Originator();
        Caretaker caretaker=new Caretaker();
        originator.setName("张三");
        originator.setSex("男");
        originator.setPassword("12345");
        System.out.println("-------------------------");
        System.out.println(originator);
        caretaker.setMemento("001",originator.createMemento());

        originator.setName("李四");
        originator.setSex("女");
        originator.setPassword("123456");
        caretaker.setMemento("002",originator.createMemento());
        System.out.println("-------------------------");
        System.out.println(originator);

        originator.setName("王五");
        originator.setSex("男");
        originator.setPassword("123456");
        System.out.println("-------------------------");
        System.out.println(originator);


        originator.restoreMemento(caretaker.getMemento("001"));
        System.out.println("-------------------------");
        System.out.println(originator);

        originator.restoreMemento(caretaker.getMemento("002"));
        System.out.println("-------------------------");
        System.out.println(originator);

    }


}
