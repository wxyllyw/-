import java.io.*;
import java.util.stream.Stream;

public class test {
    public static void main(String[] args) throws IOException {
        File file=new File("./");
        for(String f:file.list()){
            System.out.println(f);
        }





        File f=new File("./src/main/source/java/io/InputStreamReader.java");
        //Reader
        // 从文件中读出来
        FileReader fr=new FileReader(f);
        System.out.println(fr.read());

        BufferedReader br=new BufferedReader(fr);
        System.out.println(br.readLine());
        System.out.println(br.readLine());

        //输入流
        File file1=new File("./file");
        PrintWriter pw=new PrintWriter(file1);
        pw.println(br.readLine());
        pw.println(br.readLine());
        pw.flush();

        //
    }
}
